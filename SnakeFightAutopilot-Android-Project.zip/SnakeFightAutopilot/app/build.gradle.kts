plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.snakefight"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.example.snakefight"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
