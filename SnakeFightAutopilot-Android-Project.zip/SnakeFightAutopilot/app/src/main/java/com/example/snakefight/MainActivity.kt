package com.example.snakefight

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "🐍 SnakeFight Autopilot\nПрототип для Android 16"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        val status = TextView(this).apply {
            text = "Режим: ожидание\nАвтопилот пока не нажимает кнопки."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val accessibility = Button(this).apply {
            text = "1. Открыть настройки специальных возможностей"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val overlay = Button(this).apply {
            text = "2. Разрешить отображение поверх окон"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    status.text = "Разрешение поверх окон уже выдано."
                }
            }
        }
        val note = TextView(this).apply {
            text = "\nСледующий этап: захват изображения игрового поля, распознавание сетки 20×20 и безопасный маршрут с переходом через края."
            textSize = 14f
        }
        layout.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(status)
        layout.addView(accessibility)
        layout.addView(overlay)
        layout.addView(note)
        setContentView(layout)
    }
}
