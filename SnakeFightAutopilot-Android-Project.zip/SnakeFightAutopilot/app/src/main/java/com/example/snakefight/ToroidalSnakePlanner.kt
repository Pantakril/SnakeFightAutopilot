package com.example.snakefight

import java.util.ArrayDeque

/**
 * Поиск кратчайшего пути на тороидальной сетке:
 * выход за край переносит на противоположную сторону.
 * Клетки тела змейки считаются препятствиями.
 */
object ToroidalSnakePlanner {
    enum class Direction { UP, RIGHT, DOWN, LEFT }
    data class Cell(val x: Int, val y: Int)

    private data class Node(val cell: Cell, val first: Direction?)

    fun nextDirection(
        width: Int,
        height: Int,
        head: Cell,
        food: Cell,
        blocked: Set<Cell>
    ): Direction? {
        if (width <= 0 || height <= 0) return null
        val queue = ArrayDeque<Node>()
        val visited = mutableSetOf(head)
        queue.add(Node(head, null))

        val moves = listOf(
            Direction.UP to Cell(0, -1),
            Direction.RIGHT to Cell(1, 0),
            Direction.DOWN to Cell(0, 1),
            Direction.LEFT to Cell(-1, 0)
        )

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (node.cell == food) return node.first

            for ((direction, delta) in moves) {
                val next = Cell(
                    (node.cell.x + delta.x + width) % width,
                    (node.cell.y + delta.y + height) % height
                )
                if (next in visited || (next in blocked && next != food)) continue
                visited.add(next)
                queue.add(Node(next, node.first ?: direction))
            }
        }
        return null
    }
}
